
import { GoogleGenAI } from "@google/genai";
import { PERSONAL_INFO, EXPERIENCES, EDUCATION, PROJECTS, SKILL_CATEGORIES } from '../data';

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || "" });

const resumeContext = `
You are a helpful assistant for Vanshika Tushar Thakkar's portfolio website. 
Here is Vanshika's resume data:
Name: ${PERSONAL_INFO.name}
Headline: ${PERSONAL_INFO.headline}
Experience: ${JSON.stringify(EXPERIENCES)}
Education: ${JSON.stringify(EDUCATION)}
Projects: ${JSON.stringify(PROJECTS)}
Skills: ${JSON.stringify(SKILL_CATEGORIES)}

Your goal is to answer questions about Vanshika's professional background, skills, and projects in a professional, friendly, and concise manner.
If a user asks a question not related to her professional background, politely redirect them.
Keep answers brief and highlight her key impacts (like the $5M margin improvement at Deloitte).
`;

export const askResumeAssistant = async (userMessage: string) => {
  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: userMessage,
      config: {
        systemInstruction: resumeContext,
        temperature: 0.7,
      },
    });
    return response.text;
  } catch (error) {
    console.error("Gemini Error:", error);
    return "I'm sorry, I'm having trouble connecting to my brain right now. Please try again or reach out to Vanshika via LinkedIn!";
  }
};
