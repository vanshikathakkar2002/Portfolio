
import React from 'react';
import { PERSONAL_INFO } from '../data';

const Hero: React.FC = () => {
  return (
    <section className="relative pt-32 pb-20 px-6 overflow-hidden">
      {/* Decorative background gradients */}
      <div className="absolute top-0 right-0 -z-10 w-96 h-96 bg-blue-600/20 blur-[128px] rounded-full"></div>
      <div className="absolute bottom-0 left-0 -z-10 w-96 h-96 bg-purple-600/10 blur-[128px] rounded-full"></div>

      <div className="max-w-7xl mx-auto flex flex-col items-center text-center">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-500/10 border border-blue-500/20 mb-8">
          <span className="relative flex h-2 w-2">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-blue-400 opacity-75"></span>
            <span className="relative inline-flex rounded-full h-2 w-2 bg-blue-500"></span>
          </span>
          <span className="text-xs font-semibold text-blue-400 uppercase tracking-wider">Available for Roles</span>
        </div>

        <h1 className="text-5xl md:text-7xl font-extrabold tracking-tight mb-6">
          I build <span className="gradient-text">intelligent products</span> <br />
          powered by data.
        </h1>
        
        <p className="max-w-2xl text-lg md:text-xl text-gray-400 mb-10 leading-relaxed">
          Hi, I'm <span className="text-white font-medium">{PERSONAL_INFO.name}</span>. 
          A Product Analyst at UIUC specializing in automation, AI, and driving measurable business growth.
        </p>

        <div className="flex flex-col sm:flex-row gap-4">
          <a
            href="#projects"
            className="px-8 py-4 rounded-xl bg-white text-black font-bold hover:bg-gray-200 transition-all flex items-center justify-center gap-2"
          >
            View Projects
          </a>
          <a
            href={PERSONAL_INFO.linkedin}
            target="_blank"
            rel="noopener noreferrer"
            className="px-8 py-4 rounded-xl border border-gray-700 hover:border-gray-500 text-white font-bold transition-all flex items-center justify-center gap-2"
          >
            LinkedIn
          </a>
        </div>

        <div className="mt-20 flex gap-12 items-center grayscale opacity-50 hover:grayscale-0 hover:opacity-100 transition-all duration-500">
           <span className="text-2xl font-bold tracking-widest text-white/50">DELOITTE</span>
           <span className="text-2xl font-bold tracking-widest text-white/50 italic underline decoration-blue-500">COLGATE</span>
           <span className="text-2xl font-bold tracking-widest text-white/50">UIUC</span>
        </div>
      </div>
    </section>
  );
};

export default Hero;
