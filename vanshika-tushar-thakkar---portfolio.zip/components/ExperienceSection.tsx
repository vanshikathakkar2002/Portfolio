
import React from 'react';
import { EXPERIENCES, EDUCATION } from '../data';

const ExperienceSection: React.FC = () => {
  return (
    <section id="experience" className="py-24 px-6 bg-gray-900/30">
      <div className="max-w-5xl mx-auto">
        <div className="grid md:grid-cols-3 gap-16">
          <div className="md:col-span-2">
            <h2 className="text-3xl font-bold mb-12 flex items-center gap-3">
              <span className="text-blue-500">01.</span> Professional Journey
            </h2>
            <div className="space-y-12">
              {EXPERIENCES.map((exp, idx) => (
                <div key={idx} className="relative pl-8 border-l border-gray-800">
                  <div className="absolute left-0 top-0 -translate-x-1/2 w-4 h-4 rounded-full bg-blue-500 border-4 border-gray-900 shadow-[0_0_15px_rgba(59,130,246,0.5)]"></div>
                  <div className="mb-2">
                    <h3 className="text-xl font-bold text-white">{exp.role}</h3>
                    <p className="text-blue-400 font-medium">{exp.company}</p>
                    <span className="text-sm text-gray-500">{exp.period}</span>
                  </div>
                  <ul className="space-y-3 mt-4">
                    {exp.highlights.map((point, pIdx) => (
                      <li key={pIdx} className="text-gray-400 text-sm leading-relaxed flex gap-2">
                        <span className="text-blue-500/50 mt-1.5 shrink-0">•</span>
                        {point}
                      </li>
                    ))}
                  </ul>
                </div>
              ))}
            </div>
          </div>

          <div>
            <h2 className="text-3xl font-bold mb-12">Education</h2>
            <div className="space-y-8">
              {EDUCATION.map((edu, idx) => (
                <div key={idx} className="p-6 rounded-2xl bg-gray-800/40 border border-gray-700/50">
                  <h3 className="font-bold text-white">{edu.institution}</h3>
                  <p className="text-sm text-gray-400 my-1">{edu.degree}</p>
                  <div className="flex justify-between items-center mt-3">
                    <span className="text-xs font-semibold px-2 py-1 bg-blue-500/10 text-blue-400 rounded">GPA: {edu.gpa}</span>
                    <span className="text-xs text-gray-500">{edu.period}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default ExperienceSection;
